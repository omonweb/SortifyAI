"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import axios from "axios";

export default function JobPage() {
  const params = useParams();

  const [job, setJob] = useState(null);
  const [resumeCount, setResumeCount] = useState(0);

  const [results, setResults] = useState([]);
  const [selectedCandidate, setSelectedCandidate] = useState(null);

  const [hasEvaluated, setHasEvaluated] = useState(false);
  const [evaluating, setEvaluating] = useState(false);

  // FETCH JOB + RESUMES
  useEffect(() => {
    if (!params.id) return;

    const fetchData = async () => {
      try {
        const jobRes = await axios.get(
          `http://localhost:5000/job/${params.id}`
        );
        setJob(jobRes.data);

        const resRes = await axios.get(
          `http://localhost:5000/resumes/${params.id}`
        );
        setResumeCount(resRes.data.length);
      } catch (err) {
        console.error(err);
      }
    };

    fetchData();
  }, [params.id]);

  // UPLOAD HANDLER
  const handleUpload = async (files) => {
    if (!job || !files || files.length === 0) return;

    try {
      const formData = new FormData();

      files.forEach((file) => {
        formData.append("resumes", file);
      });

      formData.append("jobId", job.id);

      await axios.post(
        "http://localhost:5000/upload-resume",
        formData
      );

      // refresh count
      const res = await axios.get(
        `http://localhost:5000/resumes/${params.id}`
      );

      setResumeCount(res.data.length);
    } catch (err) {
      console.error(err);
    }
  };

  // EVALUATE HANDLER
  const handleEvaluate = async () => {
    if (!job) return;

    setEvaluating(true);

    try {
      const res = await axios.post(
        `http://localhost:5000/evaluate/${job.id}`
      );

      const sorted = res.data.sort((a, b) => b.score - a.score);

      setResults(sorted);
      setHasEvaluated(true);
    } catch (err) {
      console.error(err);
    } finally {
      setEvaluating(false);
    }
  };

  // LOADING STATE
  if (!job) {
    return (
      <div className="p-6 text-gray-500">
        Loading job...
      </div>
    );
  }

  return (
    <div className="flex gap-6">

      {/* MAIN */}
      <div className="flex-1 max-w-2xl mx-auto space-y-6">

        {/* BEFORE EVALUATION */}
        {!hasEvaluated && (
          <div className="glass p-6 space-y-4">

            <h2 className="text-lg font-semibold">
              {job.title}
            </h2>

            <p className="text-sm text-gray-600">
              {job.jd}
            </p>

            <div className="flex gap-2 flex-wrap">
              {job.skills?.map((skill, i) => (
                <span
                  key={i}
                  className="bg-white/70 px-3 py-1 rounded-full text-sm"
                >
                  {skill}
                </span>
              ))}
            </div>

            {/* UPLOAD */}
            <div className="glass p-5 flex flex-col items-center gap-3">

              <label className="cursor-pointer px-4 py-2 bg-white/80 rounded-full text-sm">
                Upload Resumes
                <input
                  type="file"
                  multiple
                  hidden
                  onChange={(e) =>
                    handleUpload([...e.target.files])
                  }
                />
              </label>

              <p className="text-xs text-gray-500">
                {resumeCount} resumes uploaded
              </p>

            </div>

            {/* EVALUATE */}
            <button
              onClick={handleEvaluate}
              disabled={!job}
              className="btn-primary disabled:opacity-50"
            >
              {evaluating ? "Evaluating..." : "Evaluate Candidates"}
            </button>

          </div>
        )}

        {/* AFTER EVALUATION */}
        {hasEvaluated && (
          <>
            <button
              onClick={() => setHasEvaluated(false)}
              className="text-sm text-blue-600"
            >
              Upload more resumes
            </button>

            <div className="space-y-3">

              <h2 className="text-lg font-semibold">
                Ranked Candidates
              </h2>

              {results.map((res, index) => (
                <div
                  key={index}
                  onClick={() => setSelectedCandidate(res)}
                  className={`glass p-4 flex justify-between cursor-pointer transition ${
                    index === 0
                      ? "border border-green-500 bg-green-50/50"
                      : index < 3
                      ? "border border-green-300 bg-green-50/30"
                      : ""
                  }`}
                >
                  <div>
                    <p className="font-medium">
                      {res.name}
                    </p>
                    <p className="text-xs text-gray-500">
                      Rank #{index + 1}
                    </p>
                  </div>

                  <p
                    className={`font-semibold ${
                      index < 3 ? "text-green-600" : ""
                    }`}
                  >
                    {res.score}
                  </p>
                </div>
              ))}

            </div>
          </>
        )}

      </div>

      {/* RIGHT PANEL */}
      <div className="w-[320px]">

        {selectedCandidate ? (
          <div className="glass p-6 sticky top-6">

            <h2 className="font-semibold mb-4">
              {selectedCandidate.name}
            </h2>

            {/* SKILLS */}
            <div className="mb-4">
              <p className="text-sm font-medium mb-1">
                Skill Match
              </p>
              <div className="flex gap-2 flex-wrap">
                {selectedCandidate.matchedSkills?.map((s, i) => (
                  <span
                    key={i}
                    className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-sm"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>

            {/* MISSING */}
            <div className="mb-4">
              <p className="text-sm font-medium mb-1">
                Missing Skills
              </p>
              <div className="flex gap-2 flex-wrap">
                {selectedCandidate.missingSkills?.map((s, i) => (
                  <span
                    key={i}
                    className="bg-red-100 text-red-600 px-2 py-1 rounded-full text-sm"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>

            {/* SUMMARY */}
            <p className="text-sm text-gray-700">
              {selectedCandidate.summary}
            </p>

          </div>
        ) : (
          <div className="text-sm text-gray-500 p-6">
            Select a candidate
          </div>
        )}

      </div>

    </div>
  );
}